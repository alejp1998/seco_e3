Hemos subido el codigo a un repositorio de github: https://github.com/alejp1998/seco_e3.git

git clone https://github.com/alejp1998/seco_e3.git
cd seco_e3

